/*
 * SosiaPos.java
 *
 * Created on 2006/05/01, 21:13
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.geobeck.sosia.pos.main;

import java.awt.event.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.logging.*;
import javax.swing.*;

import com.geobeck.swing.*;
import com.geobeck.sosia.pos.util.*;
import com.geobeck.sosia.pos.login.*;
import com.geobeck.sosia.pos.system.SystemInfo;

import java.util.zip.*;

/**
 * ���C������
 * @author katagiri
 */
public class SosiaPos
{
	public static final String VERSION		=	"0.3.8";
	/**
	 * �A�C�R���̃p�X
	 */
	public static final String	ICON_PATH	=	"/images/common/icon/icon16.gif";
	
	/**
	 * ��d�N���`�F�b�N�Ɏg���|�[�g
	 */
	private static	int				PORT	=	3776;
	/**
	 * ��d�N���`�F�b�N�Ɏg���\�P�b�g
	 */
	private static	ServerSocket	sock	=	null;
	
	/**
	 * ���C���t���[��
	 */
	private static	MainFrame mf = null;
	
        /**
         * �N�����b�Z�[�W�_�C�A���O
         */
        public static WaitDialog waitDialog = null;
        
	/**
	 * �R���X�g���N�^
	 */
	public SosiaPos()
	{
	}
	
	/**
	 * ���C���t���[�����Z�b�g����B
	 * @param mf ���C���t���[��
	 */
	public static void setMainFrameTitle(String s)
	{
		if (SosiaPos.mf != null) {
                    SosiaPos.mf.setMessageTitle(s);
                }
	}

	/**
	 * ���C������
	 * @param args ����
	 */
	public static void main(String args[])
	{
                SystemInfo.setBootOS(System.getProperty("os.name"));

		try
		{
			MessageUtil.readMassageFile();

			//��d�N���`�F�b�N
			if(!SosiaPos.checkSingleProcess())
			{
				System.exit(0);
			}

			//Look&Feel��ݒ�
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
//			UIManager.setLookAndFeel("net.sourceforge.napkinlaf.NapkinLookAndFeel");
//			SynthLookAndFeel synth = new SynthLookAndFeel();
//			synth.load(SynthFrame.class.getResourceAsStream("demo.xml"), SynthFrame.class);
//			UIManager.setLookAndFeel(synth);
		}
		catch(Exception e)
		{
			System.out.println(UIManager.getSystemLookAndFeelClassName());
		}
		
                SystemInfo.getLogger().log(Level.INFO, "SOSIA POS �N����...");

                // �N�������b�Z�[�W�\��
                waitDialog = new WaitDialog();
                waitDialog.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
                waitDialog.setLocationRelativeTo(null);
                waitDialog.setVisible(true);

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
                if (!SystemInfo.getBaseConnection().getUrl().startsWith("jdbc:postgresql://127.0.0.1:5432")) {
                    
                    String fileName = SystemInfo.getLogRoot() + "/xulrunner.zip";
                    String dirName = SystemInfo.getLogRoot() + "/xulrunner";
                    
                    // xulrunner�_�E�����[�h
                    try {


                        if (!(new File(dirName)).exists()) {

                            URL url = null;
                            if (SystemInfo.isWindows()) {
                                url = new URL("http://pos.sosia.jp:5051/hair/xulrunner.zip");
                            } else {
                                url = new URL("http://pos.sosia.jp:5051/hair/mac/xulrunner.zip");
                            }

                            URLConnection conn = url.openConnection();
                            InputStream in = conn.getInputStream();

                            File file = new File(fileName); // �ۑ���
                            FileOutputStream out = new FileOutputStream(file, false);
                            byte[] bytes = new byte[512];
                            while(true){
                                int ret = in.read(bytes);
                                if(ret == -1) break;
                                out.write(bytes, 0, ret);
                            }
                            out.close();
                            in.close();

                            File f = new File(fileName); 
                            unzip(f);
                            f.delete();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    
                    System.setProperty("user.dir", dirName);
                    System.setProperty("mozswing.xulrunner.home", dirName);
                }
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
                
		final LoginDialog login = new LoginDialog(SosiaPos.VERSION, null);

		login.addWindowListener(new WindowAdapter()
		{
		    public void windowClosing(WindowEvent we)
				{
			SosiaPos.closeApplication();
		    }
		});
		
		login.addComponentListener(new java.awt.event.ComponentAdapter()
		{
		    public void componentHidden(java.awt.event.ComponentEvent evt)
		    {
			if(login.isLogin())
			{
				SosiaPos.mf = new MainFrame();
                                SosiaPos.mf.setLocationRelativeTo(null);
				SosiaPos.mf.setVisible(true);
			}
			else
			{
				SosiaPos.closeApplication();
			}
		    }
		});
		
		login.setVisible(true);

		//temp�̍폜
		TempDeleteThread td = new TempDeleteThread();
		td.start();
                
                //Windows�V���b�g�_�E�����̏���
                Runtime.getRuntime().addShutdownHook(new ShutdownThread());
	}
	
	/**
	 * ��d�N���`�F�b�N���s���B
	 * @return ��d�N���ł͖����ꍇtrue
	 */
	private static boolean checkSingleProcess()
	{
		
		if(isSingleProcess())
		{
			return	true;
		}
		else
		{
            MessageDialog.showMessageDialog(null,
					MessageUtil.getMessage(1),
					"Sosia POS", JOptionPane.ERROR_MESSAGE);
            return	false;
        }
	}
	
	/**
	 * ��d�N�����Ă��邩���擾����B
	 * @return ��d�N�����Ă���ꍇtrue
	 */
	public static boolean isSingleProcess()
	{
		try
		{
			sock = new ServerSocket(SosiaPos.PORT);
		}
		catch(BindException e)
		{
			return false;
        }
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
        }
		
		return true;
    }
	
	public static void closeApplication()
	{
                SosiaPos.mf = null;

		Login.logout();
		//�I��
		SystemInfo.closeConnection();
		SystemInfo.getLogger().log(Level.INFO, "�I��");
		System.gc();
		
                try {
                    Process process = Runtime.getRuntime().exec("cmd /c taskkill /F /IM javaw.exe");
                    process.waitFor();
                } catch(Exception e) {
                    SystemInfo.getLogger().log(Level.SEVERE, e.getLocalizedMessage(), e);
                }
                
                System.exit(0);
	}

        /**
         * Zip �t�@�C���̉𓀃��\�b�h
         * @param file �Ώۂ�ZIP�t�@�C��
         * @throws ZipException 
         * @throws IOException 
         */
        private static void unzip(File file) throws ZipException, IOException {

            // �Ώۂ�Zip�t�@�C���Ɠ����̃f�B���N�g�����쐬����B
            String fileName = file.getName();
            int exindex = fileName.lastIndexOf(".");
            String baseDirName = fileName.substring(0, exindex);
            File baseDir = new File(file.getParent(), baseDirName);
            if (!baseDir.mkdir()) {
                throw new FileNotFoundException(baseDir + "�̐����Ɏ��s���܂����B");
            }

            // Zip �t�@�C������ ZipEntry ��������o���A�t�@�C���ɕۑ����Ă����B
            ZipFile zipFile = new ZipFile(file);
            Enumeration<? extends ZipEntry> entries = zipFile.entries();
            while (entries.hasMoreElements()) {
                ZipEntry ze = entries.nextElement();

                // �o�͐�t�@�C��
                File outFile = new File(baseDir, ze.getName());
                if (ze.isDirectory()) {
                    // ZipEntry ���f�B���N�g���̏ꍇ�̓f�B���N�g�����쐬�B
                    outFile.mkdirs();
                } else {

                    BufferedInputStream bis = null;
                    BufferedOutputStream bos = null;
                    try {
                        // ZipFile ���� �Ώ�ZipEntry �� InputStream �����o���B
                        InputStream is = zipFile.getInputStream(ze);
                        // �����悭�ǂݍ��ނ��� BufferedInputStream �Ń��b�v����B
                        bis = new BufferedInputStream(is);

                        if (!outFile.getParentFile().exists()) {
                            // �o�͐�t�@�C���̕ۑ���f�B���N�g�������݂��Ȃ��ꍇ�́A
                            // �f�B���N�g�����쐬���Ă����B
                            outFile.getParentFile().mkdirs();
                        }

                        // �o�͐� OutputStream ���쐬�B
                        bos =
                                new BufferedOutputStream(new FileOutputStream(
                                        outFile));

                        // ���̓X�g���[������ǂݍ��݁A�o�̓X�g���[���֏������ށB
                        int ava;
                        while ((ava = bis.available()) > 0) {
                            byte[] bs = new byte[ava];
                            // ����
                            bis.read(bs);

                            // �o��
                            bos.write(bs);
                        }
                    } catch (FileNotFoundException e) {
                        throw e;
                    } catch (IOException e) {
                        throw e;
                    } finally {
                        try {
                            if (bis != null)
                                // �X�g���[���͕K�� close ����B
                                bis.close();
                        } catch (IOException e) {
                        }
                        try {
                            if (bos != null)
                                // �X�g���[���͕K�� close ����B
                                bos.close();
                        } catch (IOException e) {
                        }
                    }
                }
            }
            zipFile.close();
        }

}
